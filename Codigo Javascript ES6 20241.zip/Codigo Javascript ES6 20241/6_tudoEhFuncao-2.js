console.log(typeof Object)
/*
class Produto{}
console.log(typeof Produto)
console.log(typeof Number)
*/
/*
const Cliente = function (){}
console.log(typeof Cliente)
*/
console.log(typeof new Cliente())
