
let qualquer = 'legal'
console.log(typeof qualquer)

qualquer = 3.1516
console.log(typeof qualquer)

qualquer = new String('aew');
console.log(typeof qualquer)
console.log(typeof Object)

let pqp = true


/*
let valor = ''
let numero = 2


let prodQuimPerigoso = false //Produto Quimico Perigoso
*/