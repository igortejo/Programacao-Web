
const pesoElemento = 1.2
const pesoQuimico = Number("2.0")
/*
console.log(pesoElemento, pesoQuimico)
console.log(Number.isInteger(pesoElemento))
console.log(Number.isInteger(pesoQuimico))
*/
/*
const avaliacaoProduto = 9.871
const avaliacaoElemento = 6.871
const total = avaliacaoProduto * pesoElemento + avaliacaoElemento * pesoQuimico
const media = total / (pesoElemento + pesoQuimico)
console.log(media)


console.log((0.1 + 0.7).toFixed(2))
console.log((0.794).toFixed(2))
console.log(Number(media).toString(2))

console.log(typeof media)
console.log(typeof Object)
*/

console.log(0/0)
let numero = "123e5"

//console.log(3 + + numero)


console.log((2+2) + "2")
console.log('-3' - (-2))
console.log("show!" * 2)
console.log((0.1 + 0.7).toFixed(2))

/*
console.log((0.1 + 0.7).toFixed(3) - (0.1 + 0.7).toFixed(1))
console.log((0.1 + 0.7).toFixed(1))
console.log((10.36).toFixed(1))
*/

//console.log((0.4 + 0.7))

