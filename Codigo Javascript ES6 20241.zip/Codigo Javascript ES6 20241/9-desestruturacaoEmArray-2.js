/*
const [,,a,,b] = [10, 3, 56, 89, 10]
console.log(a,b)
*/
/*
const [n0,,,n3,] = [10, 7, 9, 8]
console.log(n0, n3)
*/

const [, [, notaBaixa]] = [[, 5, 4], [1, 6, 2]]
console.log(notaBaixa)






